﻿namespace CodingAssignment.Models
{
    public class CityViewModel
    {
        public int Id { get; set; }
        public string CityName { get; set; }
    }
}
