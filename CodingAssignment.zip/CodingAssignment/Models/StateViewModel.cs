﻿namespace CodingAssignment.Models
{
    public class StateViewModel
    {
        public int Id { get; set; }
        public string StateName { get; set; }
    }
}
